import axios from "axios";
import { getToken } from "./authStorage";

// En prod: define VITE_API_URL=http://localhost:8000
// En dev sin backend: define VITE_API_MODE=mock
export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:8000",
  timeout: 20_000,
});

api.interceptors.request.use((config) => {
  const token = getToken();
  if (token) {
    config.headers = config.headers ?? {};
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});
