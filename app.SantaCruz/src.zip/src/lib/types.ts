export type Role = "ADMIN" | "OPERARIO";

export type TicketStatus = "PENDIENTE" | "EN_PREPARACION" | "PARCIAL" | "LISTO" | "CANCELADO";
export type ItemStatus = "PENDIENTE" | "EN_PREPARACION" | "ENTREGADO" | "CANCELADO";

export interface User {
  id?: string;
  username: string;
  name: string;
  role: Role;
}

export interface LoginResponse {
  access_token: string;
  user: User;
}

export interface TicketCard {
  id: string;
  comanda_number: number;
  mesa_ref?: string | null;
  mesero_nombre?: string | null;
  pos_consec_docto?: number | null;
  status: TicketStatus;
  hora_pedido: string;
  hora_preparacion?: string | null;
  hora_entrega?: string | null;
}

export interface TicketItem {
  id: string;
  product_name: string;
  qty: number;
  unidad?: string | null;
  status: ItemStatus;
}

export interface TicketDetail extends TicketCard {
  items: TicketItem[];
}

export interface SyncRunResult {
  run_id: string;
  mode: "AUTO" | "MANUAL";
  new_tickets: number;
  updated_tickets: number;
  errors: number;
  started_at: string;
  ended_at?: string | null;
}
