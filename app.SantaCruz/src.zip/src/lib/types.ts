export type UserRole = "ADMIN" | "OPERARIO";

/**
 * Alias para compatibilidad con código/mocks existentes
 */
export type Role = UserRole;

export type TicketStatus =
  | "PENDIENTE"
  | "EN_PREPARACION"
  | "PARCIAL"
  | "LISTO"
  | "CANCELADO";

export type ItemStatus =
  | "PENDIENTE"
  | "EN_PREPARACION"
  | "ENTREGADO"
  | "CANCELADO";

export type User = {
  id?: string;
  username?: string;
  name: string;
  role: UserRole;
  is_active?: boolean;
};

export type AuthTokenResponse = {
  access_token: string;
  token_type?: string;
  user: User;
};

/**
 * Alias para compatibilidad con mocks y código existente
 */
export type LoginResponse = AuthTokenResponse;

export type TicketItem = {
  id: string;
  ticket_id?: string;
  pos_movto_guid?: string;
  pos_rowid_item_ext?: number;
  product_name: string | null;
  unidad: string | null;
  qty: number;
  status: ItemStatus;
  pos_ts_actualizacion?: string | null;
  prep_started_at?: string | null;
  delivered_at?: string | null;
  canceled_at?: string | null;
  replaced_by?: string | null;
  change_reason?: string | null;
  created_at?: string;
  updated_at?: string;
};

export type TicketCard = {
  id: string;
  pos_docto_guid?: string;
  pos_id_cia?: number;
  pos_co?: string | null;
  pos_tipo_docto?: string | null;
  pos_consec_docto?: number | null;
  mesa_ref: string | null;
  pos_rowid_mesa?: number | null;
  pos_rowid_mesero?: number | null;
  mesero_nombre: string | null;
  hora_pedido: string;
  pos_ts_actualizacion?: string | null;
  status: TicketStatus;
  hora_preparacion?: string | null;
  hora_entrega?: string | null;
  comanda_number?: number | null;
  notas?: string | null;
  created_at?: string;
  updated_at?: string;
};

export type TicketDetail = TicketCard & {
  items: TicketItem[];
};

export type TicketEvent = {
  id: string;
  ticket_item_id?: string | null;
  event_type: string;
  from_status?: string | null;
  to_status?: string | null;
  user_id?: string | null;
  user_name?: string | null;
  payload?: Record<string, unknown> | null;
  event_at?: string;
  created_at?: string;
};

export type SyncRunResult = {
  ok: boolean;
  run_id?: string;
  mode?: "MANUAL" | "AUTO";
  new_tickets: number;
  updated_tickets: number;
  new_items: number;
  updated_items?: number;
  skipped_items?: number;
  total_doctos_sqlserver?: number;
  used_rowversion?: boolean;
  used_fallback_without_date_filter?: boolean;
  last_sync_at?: string | null;
  last_rowversion?: number | null;
};

export type SyncRun = {
  id: string;
  source: string;
  mode: "MANUAL" | "AUTO";
  status: "RUNNING" | "SUCCESS" | "ERROR";
  tipo_docto?: string | null;
  lookback_minutes?: number | null;
  limit_rows?: number | null;
  total_doctos_sqlserver: number;
  new_tickets: number;
  updated_tickets: number;
  new_items: number;
  updated_items: number;
  skipped_items: number;
  used_rowversion: boolean;
  used_fallback_without_date_filter: boolean;
  last_sync_at?: string | null;
  last_rowversion?: number | null;
  started_at: string;
  ended_at?: string | null;
  duration_ms?: number | null;
  error_message?: string | null;
  created_at: string;
};