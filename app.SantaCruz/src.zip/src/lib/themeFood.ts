import type { TicketStatus, ItemStatus } from "./types";

export const ticketTone = (status: TicketStatus) => {
  switch (status) {
    case "PENDIENTE":
      return {
        border: "border-l-food-mustard",
        bg: "bg-yellow-50",
        pill: "bg-food-mustard text-white",
      };

    case "EN_PREPARACION":
      return {
        border: "border-l-food-wine",
        bg: "bg-red-50",
        pill: "bg-food-wine text-white",
      };

    case "PARCIAL":
      return {
        border: "border-l-food-orange",
        bg: "bg-orange-50",
        pill: "bg-food-orange text-white",
      };

    case "LISTO":
      return {
        border: "border-l-food-olive",
        bg: "bg-lime-50",
        pill: "bg-food-olive text-white",
      };

    case "CANCELADO":
      return {
        border: "border-l-stone-300",
        bg: "bg-stone-100",
        pill: "bg-stone-400 text-white",
      };

    default:
      return {
        border: "border-l-stone-300",
        bg: "bg-white",
        pill: "bg-stone-300 text-stone-900",
      };
  }
};

export const itemTone = (status: ItemStatus) => {
  switch (status) {
    case "PENDIENTE":
      return "bg-yellow-100 text-yellow-900";

    case "EN_PREPARACION":
      return "bg-red-100 text-red-900";

    case "ENTREGADO":
      return "bg-green-100 text-green-900";

    case "CANCELADO":
      return "bg-stone-200 text-stone-800";

    default:
      return "bg-stone-200 text-stone-800";
  }
};
