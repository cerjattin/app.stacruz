import type { ItemStatus, TicketStatus } from "./types";

export function ticketStatusPillClass(status: TicketStatus): string {
  const base = "inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold";
  switch (status) {
    case "PENDIENTE":
      return `${base} bg-amber-100 text-amber-800`;
    case "EN_PREPARACION":
      return `${base} bg-blue-100 text-blue-800`;
    case "PARCIAL":
      return `${base} bg-violet-100 text-violet-800`;
    case "LISTO":
      return `${base} bg-emerald-100 text-emerald-800`;
    case "CANCELADO":
      return `${base} bg-slate-200 text-slate-700`;
    default:
      return `${base} bg-slate-100 text-slate-700`;
  }
}

export function itemStatusPillClass(status: ItemStatus): string {
  const base = "inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold";
  switch (status) {
    case "PENDIENTE":
      return `${base} bg-amber-100 text-amber-800`;
    case "EN_PREPARACION":
      return `${base} bg-blue-100 text-blue-800`;
    case "ENTREGADO":
      return `${base} bg-emerald-100 text-emerald-800`;
    case "CANCELADO":
      return `${base} bg-slate-200 text-slate-700`;
    default:
      return `${base} bg-slate-100 text-slate-700`;
  }
}

export function statusLabel(status: TicketStatus | ItemStatus): string {
  switch (status) {
    case "EN_PREPARACION":
      return "En preparación";
    case "PENDIENTE":
      return "Pendiente";
    case "PARCIAL":
      return "Parcial";
    case "LISTO":
      return "Listo";
    case "ENTREGADO":
      return "Entregado";
    case "CANCELADO":
      return "Cancelado";
    default:
      return status;
  }
}

export function formatTime(iso: string | null | undefined): string {
  if (!iso) return "—";
  try {
    const d = new Date(iso);
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  } catch {
    return "—";
  }
}
