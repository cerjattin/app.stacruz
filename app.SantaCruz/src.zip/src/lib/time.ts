// src/lib/time.ts

export function minutesSince(dateStr: string): number {
  const date = new Date(dateStr);
  const now = new Date();
  return Math.floor((now.getTime() - date.getTime()) / 60000);
}

export function ageTone(minutes: number): "ok" | "warn" | "danger" {
  if (minutes <= 10) return "ok";
  if (minutes <= 20) return "warn";
  return "danger";
}