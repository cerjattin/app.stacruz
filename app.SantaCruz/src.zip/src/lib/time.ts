import type { TicketStatus } from "./types";

export type AgeTone = "ok" | "warn" | "danger";

export function parseDate(value?: string | null): Date | null {
  if (!value) return null;
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d;
}

export function minutesSince(value?: string | null): number {
  const d = parseDate(value);
  if (!d) return 0;
  return Math.max(0, Math.floor((Date.now() - d.getTime()) / 60000));
}

export function ageTone(minutes: number): AgeTone {
  if (minutes >= 25) return "danger";
  if (minutes >= 12) return "warn";
  return "ok";
}

export function ticketPriorityValue(status: TicketStatus, minutes: number): number {
  const statusWeight =
    status === "PENDIENTE"
      ? 400
      : status === "EN_PREPARACION"
      ? 300
      : status === "PARCIAL"
      ? 200
      : status === "LISTO"
      ? 50
      : 0;

  const ageWeight =
    minutes >= 25
      ? 100
      : minutes >= 12
      ? 50
      : 10;

  return statusWeight + ageWeight;
}

export function compareTicketPriority(
  a: { status: TicketStatus; hora_pedido?: string | null; mesa_ref?: string | null },
  b: { status: TicketStatus; hora_pedido?: string | null; mesa_ref?: string | null }
): number {
  const aMin = minutesSince(a.hora_pedido);
  const bMin = minutesSince(b.hora_pedido);

  const pa = ticketPriorityValue(a.status, aMin);
  const pb = ticketPriorityValue(b.status, bMin);

  if (pb !== pa) return pb - pa;

  if (bMin !== aMin) return bMin - aMin;

  const mesaA = (a.mesa_ref ?? "").toString();
  const mesaB = (b.mesa_ref ?? "").toString();
  return mesaA.localeCompare(mesaB, "es", { numeric: true, sensitivity: "base" });
}