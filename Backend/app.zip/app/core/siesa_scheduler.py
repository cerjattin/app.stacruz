from __future__ import annotations

import threading
import time

from app.db.session import SessionLocal
from app.services.siesa_sync_service import run_siesa_sync


def _sync_loop():
    while True:
        db = SessionLocal()
        try:
            run_siesa_sync(db, tipo_docto="01f", lookback_minutes=1440, limit=300)
        except Exception as e:
            print(f"[SIESA SYNC LOOP] Error: {e}")
        finally:
            db.close()

        time.sleep(300)  # 5 minutos


def start_siesa_scheduler():
    t = threading.Thread(target=_sync_loop, daemon=True)
    t.start()